Put your custom character icons here!
Icons must start with "icon-" or it won't be read!
The image resolution must have a minimal of 150x150

For other icon sizes:
2 - 300x150
3 - 450x150
5 - 750x150

I know, it's weird that there isn't one for 4 icons, because that would also be weird.