scripts in this folder will run on every song!
but you probably already knew that

anyways, you can either use lua scripts OR haxe scripts!
the following extensions for haxe scripts are allowed: [.hx, .hxc, .hxs, .hscript]

If you've put it inside a modpack, as long as the modpack is loaded, the script will be running.