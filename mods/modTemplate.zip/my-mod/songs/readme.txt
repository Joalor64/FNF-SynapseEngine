Put your custom songs and charts here
It should be a folder with your custom song's name, and inside of it should include two files: "Inst.ogg" and "Voices.ogg"
It should also include the song's chart(s): "song.json" and "song-hard.json" for example