Put your custom credit icons here!
The image resolution must be a minimal of 150x150