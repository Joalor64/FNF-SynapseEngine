Your custom translation files go here!
Copy en-US.lang, rename it to your language (like es-ES.lang) and translate it.
See the comments at the top of en-US.lang for how the format works.